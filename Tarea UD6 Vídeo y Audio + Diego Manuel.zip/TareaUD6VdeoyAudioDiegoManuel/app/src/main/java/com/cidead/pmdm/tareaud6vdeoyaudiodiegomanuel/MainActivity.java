package com.cidead.pmdm.tareaud6vdeoyaudiodiegomanuel;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    VideoView video;
    Button btPlay, btPause, btContinuar, btDetener;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mediaPlayer = MediaPlayer.create(this,R.raw.a_el_hombre_pajaro);
        mediaPlayer.start();
        video = (VideoView) findViewById(R.id.video);
        btPlay = (Button) findViewById(R.id.btPlay);
        btPause = (Button) findViewById(R.id.btPause);
        btContinuar = (Button) findViewById(R.id.btContinuar);
        btDetener = (Button) findViewById(R.id.btDetener);
        estVideo();

        btPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playAudio();
            }
        });

        btPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pausaAudio();
            }
        });

        btContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contAudio();
            }
        });

        btDetener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAudio();
            }
        });
    }

    private void estVideo(){

        String ruta = "android.resource://" + getPackageName() + "/" + R.raw.v_azulitos;
        Uri uri = Uri.parse(ruta);
        MediaController mediaController = new MediaController(this);
        try {
            video.setMediaController(mediaController);
            video.setVideoURI(uri);
            video.requestFocus();
        }catch (Exception e){
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }

        video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                video.start();
            }
        });
    }

    private void playAudio() {

        mediaPlayer = MediaPlayer.create(this,R.raw.a_el_hombre_pajaro);
        mediaPlayer.start();
    }

    private void pausaAudio() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    private void contAudio() {
        if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    private void stopAudio() {
        mediaPlayer.stop();
    }

}